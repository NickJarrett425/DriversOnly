from django.contrib import admin
from .models import about

admin.site.register(about)