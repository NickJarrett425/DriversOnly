from django.contrib import admin
from application.models import Application

# Register your models here.
admin.site.register(Application)
