from django.db import models

# Create your models here.

class Product(models.Model):
    image = models.ImageField(upload_to='product_images/', null=True, blank=True)
    name = models.CharField(max_length=255,blank=True)
    artist = models.CharField(max_length=255, blank=True)
    genre = models.CharField(max_length=255, blank=True)
    description = models.TextField(max_length=250, blank=True)
    point_price = models.IntegerField(default=0)
    # Add other fields as needed
